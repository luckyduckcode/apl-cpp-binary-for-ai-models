// some strings exported from Makefile
//
#define Makefile__bindir     "/usr/bin"
#define Makefile__docdir     "/usr/share/doc/apl"
#define Makefile__sysconfdir "/etc"
#define Makefile__pkglibdir  "/usr/lib/apl"
#define Makefile__localedir  "/usr/share/locale"
#define Makefile__srcdir     "/home/eedjsa/projects/juergen/apl-1.8/src"
#define Makefile__host_os    "linux-gnu"

